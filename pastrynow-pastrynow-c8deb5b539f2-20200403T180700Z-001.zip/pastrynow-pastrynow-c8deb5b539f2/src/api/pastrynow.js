import { AsyncStorage } from 'react-native';

const apiUrl = 'http://console.pastrynow.com/api/v1';
// const apiUrl = 'http://192.168.43.44/api/v1';
// const apiUrl = 'http://192.168.1.45/api/v1';

async function _getToken() {
  return await AsyncStorage.getItem('accessToken');
}

export async function logout(that) {
  console.log('logout');
  await AsyncStorage.removeItem('accessToken', null);
  await AsyncStorage.removeItem('user', null);
  that.props.navigation.navigate('Auth');
}

/**
 * Private functions
 */

export function login(email, password) {
  var formData = new FormData();
  formData.append('email', email);
  formData.append('password', password);

  const options = {
    method: 'POST',
    body: formData
  };

  return callNoAuthApi('login', options);
}

export function register(name, email, password, c_password) {
  var formData = new FormData();
  formData.append('name', name);
  formData.append('email', email);
  formData.append('password', password);
  formData.append('c_password', c_password);

  const options = {
    method: 'POST',
    body: formData
  };

  return callNoAuthApi('register', options);
}

export function discover() {
  return callApi('food-items/discover');
}

export function addresses() {
  return callApi('addresses');
}

export function addAddress(street_address, address_line_2, city, state, zip) {
  var formData = new FormData();
  formData.append('street_address', street_address);
  formData.append('address_line_2', address_line_2);
  formData.append('city', city);
  formData.append('state', state);
  formData.append('zip', zip);

  const options = {
    method: 'POST',
    body: formData
  };

  return callApi('addresses', options);
}

export function submitOrder(order_for, address_id, items) {
  var formData = new FormData();
  formData.append('order_for', order_for);
  formData.append('address_id', address_id);
  formData.append('items', JSON.stringify(items));

  console.log('items: ', JSON.stringify(items));

  const options = {
    method: 'POST',
    body: formData
  };

  return callApi('orders', options);
}

export function getOrders() {
  return callApi('orders');
}

async function callNoAuthApi(endpoint, options = { method: 'get' }) {
  const url = `${apiUrl}/${endpoint}`;

  console.log('Method: ', options.method);
  console.log('Url: ', url);

  return fetch(url, {
    ...options,
    headers: {
      Accept: 'application/json'
    }
  })
    .then(res => {
      return res.text();
    })
    .then(text => {
      // debugger

      if (text === 'OK') {
        console.log('Api error');
        return [];
      }
      if (text.length === 0) {
        console.log('Network error');
        return [];
      }

      var responseJson = JSON.parse(text);
      console.log('Response:', responseJson);

      return responseJson;
    });
}

async function callApi(endpoint, options = { method: 'get' }) {
  const url = `${apiUrl}/${endpoint}`;

  const accessToken = await _getToken();

  console.log('Method: ', options.method);
  console.log('Url: ', url);
  console.log('AccessToken: ', accessToken);

  return fetch(url, {
    ...options,
    headers: {
      Authorization: `Bearer ${accessToken}`,
      Accept: 'application/json'
    }
  })
    .then(res => {
      return res.text();
    })
    .then(text => {
      // debugger

      if (text === 'OK') {
        console.log('Api error');
        return [];
      }
      if (text.length === 0) {
        console.log('Network error');
        return [];
      }

      var responseJson = JSON.parse(text);
      console.log('Response:', responseJson);

      return responseJson;
    });
}
