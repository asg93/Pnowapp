import React, { Component } from 'react';
import Dimensions from 'Dimensions';
import { ImageBackground, StyleSheet } from 'react-native';

export default class Wallpaper extends Component {
  render() {
    return (
      <ImageBackground style={styles.picture} source={this.props.source}>
        {this.props.children}
      </ImageBackground>
    );
  }
}

const imageStyle = {
  width: Dimensions.get('window').width,
  height: Dimensions.get('window').height,
  resizeMode: 'stretch'
};
const styles = StyleSheet.create({
  picture: imageStyle
});
