import React, { Component } from 'react';
import Dimensions from 'Dimensions';
import { KeyboardAvoidingView, StyleSheet } from 'react-native';

import UserInput from './UserInput';

import usernameImg from '../images/username.png';
import emailImg from '../images/email.png';
import passwordImg from '../images/password.png';

export default class RegisterForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showPass: true,
      press: false,
      isFieldEmpty: true
    };
    this.showPass = this.showPass.bind(this);
  }

  showPass() {
    this.state.press === false
      ? this.setState({ showPass: false, press: true })
      : this.setState({ showPass: true, press: false });
  }

  validateField = text => {
    console.log(text);
  };

  render() {
    const { name, select } = this.state;
    return (
      <KeyboardAvoidingView style={styles.container}>
        <UserInput
          ref="Name"
          source={usernameImg}
          placeholder="Name"
          autoCapitalize={'none'}
          returnKeyType={'next'}
          autoFocus={true}
          autoCorrect={false}
          onSubmitEditing={event => {
            this.refs.Password.focus();
          }}
          onChange={name => this.validateField(name)}
          value={name}
        />
        <UserInput
          keyboardType="email-address"
          ref="Email"
          source={emailImg}
          placeholder="Email"
          autoCapitalize={'none'}
          returnKeyType={'next'}
          autoFocus={true}
          autoCorrect={false}
          onSubmitEditing={event => {
            this.refs.Password.focus();
          }}
        />
        <UserInput
          ref="Password"
          source={passwordImg}
          secureTextEntry={this.state.showPass}
          placeholder="Password"
          returnKeyType={'done'}
          autoCapitalize={'none'}
          autoCorrect={false}
        />
        {/* <TouchableOpacity
          activeOpacity={0.7}
          style={styles.btnEye}
          onPress={this.showPass}>
          <Image source={eyeImg} style={styles.iconEye} />
        </TouchableOpacity> */}
      </KeyboardAvoidingView>
    );
  }
}

const DEVICE_WIDTH = Dimensions.get('window').width;
const DEVICE_HEIGHT = Dimensions.get('window').height;

const styles = StyleSheet.create({
  container: {},
  btnEye: {
    position: 'absolute',
    top: 60,
    right: 28
  },
  iconEye: {
    width: 25,
    height: 25,
    tintColor: 'rgba(0,0,0,0.2)'
  }
});
