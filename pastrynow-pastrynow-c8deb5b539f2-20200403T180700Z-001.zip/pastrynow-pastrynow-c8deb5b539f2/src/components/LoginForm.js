import React, { Component } from 'react';
import Dimensions from 'Dimensions';
import { KeyboardAvoidingView, StyleSheet } from 'react-native';

import UserInput from './UserInput';

import emailImg from '../images/email.png';
import passwordImg from '../images/password.png';

export default class LoginForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showPass: true,
      press: false
    };
    this.showPass = this.showPass.bind(this);
  }

  showPass() {
    this.state.press === false
      ? this.setState({ showPass: false, press: true })
      : this.setState({ showPass: true, press: false });
  }

  render() {
    return (
      <KeyboardAvoidingView style={styles.container}>
        <UserInput
          keyboardType="email-address"
          ref="Email"
          source={emailImg}
          placeholder="Email"
          autoCapitalize={'none'}
          returnKeyType={'next'}
          autoFocus={true}
          autoCorrect={false}
          onSubmitEditing={event => {
            this.refs.Password.focus();
          }}
        />
        <UserInput
          ref="Password"
          source={passwordImg}
          secureTextEntry={this.state.showPass}
          placeholder="Password"
          returnKeyType={'done'}
          autoCapitalize={'none'}
          autoCorrect={false}
        />
      </KeyboardAvoidingView>
    );
  }
}

const DEVICE_WIDTH = Dimensions.get('window').width;
const DEVICE_HEIGHT = Dimensions.get('window').height;

const styles = StyleSheet.create({
  container: {},
  btnEye: {
    position: 'absolute',
    top: 60,
    right: 28
  },
  iconEye: {
    width: 25,
    height: 25,
    tintColor: 'rgba(0,0,0,0.2)'
  }
});
