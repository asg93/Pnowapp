import React, { Component } from 'react';
import Dimensions from 'Dimensions';

import {
  Alert,
  Animated,
  AsyncStorage,
  Easing,
  Image,
  StyleSheet,
  Text,
  ToastAndroid,
  TouchableOpacity,
  View
} from 'react-native';
import { withNavigation } from 'react-navigation';

import * as Api from '../api/pastrynow';

import spinner from '../images/loading.gif';

const DEVICE_WIDTH = Dimensions.get('window').width;
const DEVICE_HEIGHT = Dimensions.get('window').height;
const MARGIN = 40;

class RegisterSubmit extends Component {
  constructor() {
    super();

    this.state = {
      token: null,
      name: null,
      isLoading: false
    };

    this.buttonAnimated = new Animated.Value(0);
    this.growAnimated = new Animated.Value(0);
    this._onPress = this._onPress.bind(this);
  }

  setToken = value => {
    AsyncStorage.setItem('token', value);
    this.setState({ token: value });
  };
  setName = value => {
    AsyncStorage.setItem('name', value);
    this.setState({ name: value });
  };

  showToast(message, length) {
    ToastAndroid.show(message, length);
  }

  setEmail = value => {
    AsyncStorage.setItem('email', value);
    this.setState({ email: value });
  };

  _setToken = value => {
    AsyncStorage.setItem('accessToken', value);
    this.setState({ accessToken: value });
  };
  _setUser = value => {
    AsyncStorage.setItem('user', value);
    this.setState({ user: value });
  };

  _onPress() {
    if (this.state.isLoading) {
      return;
    }
    if (this.props.isFieldEmpty) {
      this.showToast('Empty Fields', ToastAndroid.SHORT);
      return;
    }

    this.setState({ isLoading: true });

    Animated.timing(this.buttonAnimated, {
      toValue: 1,
      duration: 200,
      easing: Easing.linear
    }).start();

    Api.login(this.props.email, this.props.pass).then(responseJson => {
      if (responseJson.success === true) {
        this._setToken(responseJson.data.token.accessToken);
        this._setUser(JSON.stringify(responseJson.data.user));
        this.setState({
          isLoading: false
        });
        this.buttonAnimated.setValue(0);
        this.growAnimated.setValue(0);
        this.props.navigation.navigate('Main');
      } else {
        this.setState({
          isLoading: false
        });
        this.buttonAnimated.setValue(0);
        this.growAnimated.setValue(0);
        Alert.alert('Error', responseJson.message);
      }
    });
  }

  _onGrow() {
    Animated.timing(this.growAnimated, {
      toValue: 1,
      duration: 200,
      easing: Easing.linear
    }).start();
  }

  render() {
    const changeWidth = this.buttonAnimated.interpolate({
      inputRange: [0, 1],
      outputRange: [DEVICE_WIDTH - MARGIN, MARGIN]
    });
    const changeScale = this.growAnimated.interpolate({
      inputRange: [0, 1],
      outputRange: [1, MARGIN]
    });

    return (
      <View style={styles.container}>
        <Animated.View style={{ width: changeWidth }}>
          <TouchableOpacity
            style={styles.button}
            onPress={this._onPress}
            activeOpacity={1}
          >
            {this.state.isLoading ? (
              <Image source={spinner} style={styles.image} />
            ) : (
              <Text style={styles.text}>{this.props.text}</Text>
            )}
          </TouchableOpacity>
          <Animated.View
            style={[styles.circle, { transform: [{ scale: changeScale }] }]}
          />
        </Animated.View>
      </View>
    );
  }
}

export default withNavigation(RegisterSubmit);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-start',
    marginTop: 50
  },
  button: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'tomato',
    height: MARGIN,
    borderRadius: 20,
    zIndex: 100
  },
  circle: {
    height: MARGIN,
    width: MARGIN,
    marginTop: -MARGIN,
    borderWidth: 1,
    borderColor: 'tomato',
    borderRadius: 100,
    alignSelf: 'center',
    zIndex: 99,
    backgroundColor: 'tomato'
  },
  text: {
    color: 'white',
    backgroundColor: 'transparent'
  },
  image: {
    width: 24,
    height: 24
  }
});
