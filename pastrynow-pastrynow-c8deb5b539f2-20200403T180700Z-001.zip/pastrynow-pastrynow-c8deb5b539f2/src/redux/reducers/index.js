import { combineReducers } from 'redux';
import deliveryLocation from './deliveryLocation';
import cartItems from './cartItems';

export default combineReducers({ deliveryLocation, cartItems });
