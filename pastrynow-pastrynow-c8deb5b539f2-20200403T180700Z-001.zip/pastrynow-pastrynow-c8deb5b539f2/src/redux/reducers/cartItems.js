import {
  ADD_TO_CART,
  REMOVE_FROM_CART,
  INCREASE_CART_ITEM_COUNT,
  DECREASE_CART_ITEM_COUNT,
  EMPTY_CART
} from '../actionTypes';

const initalState = [];

const cartItems = (state = initalState, action) => {
  switch (action.type) {
    case ADD_TO_CART:
      return [...state, action.payload];
    case REMOVE_FROM_CART:
      return state.filter(cartItem => cartItem.id !== action.payload.id);
    case EMPTY_CART:
      return [];
    case INCREASE_CART_ITEM_COUNT:
      let selectedItem = state.find(item => item.id === action.id);
      console.log('addedItem: ', selectedItem);
      selectedItem.quantity = action.up + 1;
      return [...state];
    case DECREASE_CART_ITEM_COUNT:
      if (action.down === 1) {
        return state.filter(cartItem => cartItem.id !== action.id);
      } else {
        let addedItem = state.find(item => item.id === action.id);
        console.log('addedItem: ', addedItem);
        addedItem.quantity = action.down - 1;
        return [...state];
      }
  }
  return state;
};

export default cartItems;
