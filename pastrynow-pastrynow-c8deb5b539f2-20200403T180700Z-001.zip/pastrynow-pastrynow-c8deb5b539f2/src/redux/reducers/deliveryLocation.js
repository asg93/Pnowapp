import { SELECT_DELIVERY_LOCATION } from '../actionTypes';

const initialState = null;

const deliveryLocation = (state = initialState, action) => {
  switch (action.type) {
    case SELECT_DELIVERY_LOCATION: {
      return action.payload.deliveryLocation;
    }
    default: {
      return state;
    }
  }
};

export default deliveryLocation;
