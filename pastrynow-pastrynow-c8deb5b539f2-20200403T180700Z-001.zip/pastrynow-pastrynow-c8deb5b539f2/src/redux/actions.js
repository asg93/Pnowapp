import {
  SELECT_DELIVERY_LOCATION,
  ADD_TO_CART,
  REMOVE_FROM_CART,
  INCREASE_CART_ITEM_COUNT,
  DECREASE_CART_ITEM_COUNT,
  EMPTY_CART
} from './actionTypes';

export const selectDeliveryLocation = deliveryLocation => ({
  type: SELECT_DELIVERY_LOCATION,
  payload: {
    deliveryLocation: deliveryLocation
  }
});

export const addToCart = item => ({
  type: ADD_TO_CART,
  payload: item
});

export const removeFromCart = id => ({
  type: REMOVE_FROM_CART,
  payload: {
    id: id
  }
});

export const emptyCart = () => ({
  type: EMPTY_CART
});

export const quantityUp = (id, val) => ({
  type: INCREASE_CART_ITEM_COUNT,
  id: id,
  up: val
});

export const quantityDown = (id, val) => ({
  type: DECREASE_CART_ITEM_COUNT,
  id: id,
  down: val
});
