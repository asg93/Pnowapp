import React, { Component } from 'react';
import {
  ActivityIndicator,
  AsyncStorage,
  SafeAreaView,
  StyleSheet,
  View
} from 'react-native';
import { Button, Text } from 'native-base';
import * as Api from '../api/pastrynow';

export default class AccountScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: true,
      details: null
    };
  }

  static navigationOptions = ({ navigation }) => {
    return {
      title: 'Account',
      tabBarVisible: 'false'
    };
  };

  componentDidMount() {
    this.loadDetails();
  }

  loadDetails = async () => {
    this.setState({ isLoading: true });
    try {
      const user = await AsyncStorage.getItem('user');
      if (user !== null) {
        this.setState({
          isLoading: false,
          details: JSON.parse(user)
        });
      } else {
        Api.logout(this);
      }
    } catch (error) {
      // Error retrieving data
    }
  };

  onLogout() {
    Api.logout(this);
  }

  render() {
    if (this.state.isLoading) {
      return (
        <SafeAreaView style={{ flex: 1 }}>
          <View style={styles.emptyContainer}>
            <ActivityIndicator />
          </View>
        </SafeAreaView>
      );
    } else {
      return (
        <View style={styles.container}>
          <Text style={styles.heading}>Account Details</Text>
          <Text style={styles.details}>Name: {this.state.details.name}</Text>
          <Text style={styles.details}>Email: {this.state.details.email}</Text>
          <View style={styles.bottom}>
            <Button
              danger
              onPress={() => this.onLogout()}
              style={styles.logoutButton}
            >
              <Text>Logout</Text>
            </Button>
          </View>
          <View style={styles.centerAlign}>
            <Text>Version 1.0.3.21</Text>
          </View>
        </View>
      );
    }
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5FCFF'
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF'
  },
  centerAlign: {
    alignItems: 'center',
    justifyContent: 'center'
  },
  centerHeading: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10
  },
  heading: {
    fontSize: 20,
    margin: 10,
    fontWeight: 'bold'
  },
  details: {
    fontSize: 15,
    margin: 10
  },
  bakerSection: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center'
  },
  bakerButtons: {
    margin: 5
  },
  bottom: {
    flex: 1,
    justifyContent: 'flex-end',
    marginBottom: 36
  },
  logoutButton: {
    alignSelf: 'center'
  }
});
