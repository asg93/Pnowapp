import React, { Component } from 'react';
import {
  ActivityIndicator,
  AsyncStorage,
  Dimensions,
  Image,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Animated
} from 'react-native';

import CardStack, { Card } from 'react-native-card-stack-swiper';
import StarRating from 'react-native-star-rating';

import { connect } from 'react-redux';

import * as Api from '../api/pastrynow';
import { addToCart, removeFromCart } from '../redux/actions';

var screenWidth = Dimensions.get('window').width;
var screenHeight = Dimensions.get('window').height;
var cardWidth = (screenWidth / 4) * 3;
var cardHeight = screenHeight / 2;
var cardImageHeight = (screenWidth / 4) * 2.5;

class RecipeScreen extends Component<> {
  constructor(props) {
    super(props);
    this.state = {
      cards: null,
      isLoading: true,
      cartItems: []
    };
  }

  animatedValue = new Animated.Value(0);

  onStarRatingPress(rating) {
    this.setState({
      starCount: rating
    });
  }

  componentDidMount() {
    this.discover();
  }

  discover = () => {
    this.setState({
      isLoading: true
    });
    Api.discover().then(responseJson => {
      if (
        responseJson.success === false &&
        responseJson.message === 'unauthenticated'
      ) {
        Api.logout(this);
      } else if (responseJson.success === true) {
        this.setState({
          isLoading: false,
          cards: responseJson.data
        });
      }
    });
  };

  _onSwipedRight = index => {
    // AsyncStorage.getItem('cartItems', (err, result) => {
    //   var resultJson = JSON.parse(result);
    //   if (resultJson !== null) {
    //     resultJson.push(this.state.cards[index]);
    //     AsyncStorage.setItem('cartItems', JSON.stringify(resultJson));
    //   } else {
    //     resultJson = [];
    //     resultJson[0] = this.state.cards[index];
    //     AsyncStorage.setItem('cartItems', JSON.stringify(resultJson));
    //   }
    //   Animated.sequence([
    //     Animated.spring(this.animatedValue, { toValue: 1 }),
    //     Animated.spring(this.animatedValue, { toValue: 0 })
    //   ]).start();
    // });
    this.props.addToCart(this.state.cards[index]);
    Animated.sequence([
      Animated.spring(this.animatedValue, { toValue: 1 }),
      Animated.spring(this.animatedValue, { toValue: 0 })
    ]).start();
  };

  _onSwipedLeft = index => {};

  renderCards = (item, key) => {
    return (
      <Card
        key={key}
        style={{
          width: cardWidth,
          minHeight: cardHeight,
          backgroundColor: '#fff'
        }}
      >
        <View style={{ paddingHorizontal: 10 }}>
          <Image
            // source={{uri: item.image}}
            source={{ uri: item.image }}
            resizeMode={'cover'}
            style={{
              height: cardImageHeight,
              width: null,
              marginTop: -20
            }}
          />
          <View
            style={{
              borderBottomWidth: 1,
              borderColor: '#F5F5F5'
            }}
          >
            <View style={{ position: 'relative' }}>
              <Image
                source={{ uri: item.chef.image }}
                style={{
                  position: 'absolute',
                  left: 10,
                  top: -20,
                  width: 40,
                  height: 40,
                  borderRadius: 20,
                  borderColor: '#fff',
                  borderWidth: 2
                }}
              />
              <Text
                style={{
                  textAlign: 'left',
                  paddingLeft: 70,
                  paddingVertical: 3
                }}
              >
                {item.chef.name}
              </Text>
            </View>
            <View style={styles.foodDetail}>
              <View style={styles.flex1}>
                <Text style={styles.foodName}>{item.name}</Text>
              </View>
              <View style={styles.flex1}>
                <Text style={styles.foodCost}>${item.amount}</Text>
              </View>
              <View style={styles.starRateView}>
                <View style={styles.starRate}>
                  <StarRating
                    disabled={true}
                    maxStars={5}
                    rating={item.stars}
                    fullStarColor={'gold'}
                    starSize={12}
                    selectedStar={rating => this.onStarRatingPress(rating)}
                  />
                </View>
                <View style={styles.flex1}>
                  <Text style={styles.starRateValue}>{item.stars}</Text>
                </View>
              </View>
              <View style={{ paddingBottom: 10 }}>
                <Text>Food Category - {item.category} </Text>
                <Text>Spice Level - {item.spice_level}</Text>
                <Text>Allergy - {item.allergy}</Text>
              </View>
            </View>
          </View>
        </View>
      </Card>
    );
  };

  renderOverlay = () => {
    return (
      <Animated.View
        style={[
          styles.overlay,
          {
            opacity: this.animatedValue,
            transform: [
              {
                scale: this.animatedValue.interpolate({
                  inputRange: [0, 1],
                  outputRange: [0.7, 1.5]
                })
              }
            ]
          }
        ]}
        pointerEvents={'box-none'}
      >
        <Image
          style={{ width: 40, height: 40 }}
          source={require('../images/cart_green.png')}
        />
        <Text style={{ color: '#4caf50', marginTop: 20, fontSize: 11 }}>
          Added to cart
        </Text>
      </Animated.View>
    );
  };

  render() {
    if (this.state.isLoading) {
      return (
        <SafeAreaView style={{ flex: 1 }}>
          <View style={[styles.parentView, styles.center, styles.blackBg]}>
            {/*<Image*/}
            {/*    style={{position:"absolute", height: screenHeight, width: screenWidth, resizeMode: "cover"}}*/}
            {/*    source={require('../images/background.jpg')}*/}
            {/*    blurRadius={4}*/}
            {/*/>*/}
            <ActivityIndicator />
          </View>
        </SafeAreaView>
      );
    }

    return (
      <SafeAreaView style={{ flex: 1 }}>
        <View style={{ backgroundColor: '#fff', position: 'absolute' }} />
        <View style={[styles.parentView, styles.blackBg]}>
          {/*<Image*/}
          {/*    style={{position:"absolute", height: screenHeight, width: screenWidth, resizeMode: "cover"}}*/}
          {/*    source={require('../images/background.jpg')}*/}
          {/*    blurRadius={4}*/}
          {/*/>*/}
          {/*<View style={styles.headerText}>*/}
          {/*  <Text*/}
          {/*    style={{*/}
          {/*      textAlign: 'center',*/}
          {/*      color: 'white',*/}
          {/*      fontSize: 18,*/}
          {/*      textTransform: 'uppercase'*/}
          {/*    }}*/}
          {/*  >*/}
          {/*    Menu*/}
          {/*  </Text>*/}
          {/*</View>*/}
          <CardStack
            style={[styles.cardStack, styles.blackBg]}
            renderNoMoreCards={() => (
              <Text style={{ fontWeight: '700', fontSize: 18, color: '#fff' }}>
                Empty
              </Text>
            )}
            ref={swiper => {
              this.swiper = swiper;
            }}
            verticalSwipe={false}
            onSwipedRight={index => this._onSwipedRight(index)}
            onSwipedLeft={index => this._onSwipedLeft(index)}
            loop={true}
          >
            {this.state.cards.map(
              (item, key) => this.renderCards(item, key),
              this
            )}
          </CardStack>

          <View style={[styles.footer, styles.blackBg]}>
            <View style={styles.buttonContainer}>
              <TouchableOpacity
                style={[styles.button, styles.red]}
                onPress={() => {
                  this.swiper.swipeLeft();
                }}
              >
                <Image
                  source={require('../images/cancel.png')}
                  resizeMode={'contain'}
                  style={{ height: 30, width: 30 }}
                />
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.button, styles.orange]}
                onPress={() => {
                  this.componentDidMount();
                }}
              >
                <Image
                  source={require('../images/reload.png')}
                  resizeMode={'contain'}
                  style={{ height: 30, width: 30 }}
                />
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.button, styles.green]}
                onPress={() => {
                  this.swiper.swipeRight();
                }}
              >
                <Image
                  source={require('../images/like_filled.png')}
                  resizeMode={'contain'}
                  style={{ height: 30, width: 30 }}
                />
              </TouchableOpacity>
            </View>
          </View>
        </View>
        {this.renderOverlay()}
      </SafeAreaView>
    );
  }
}

function mapStateToProps(state) {
  return {
    cartItems: state.cartItems
  };
}

function mapDispatchToProps(dispatch) {
  return {
    addToCart: item => dispatch(addToCart(item))
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(RecipeScreen);

const styles = StyleSheet.create({
  parentView: {
    flex: 1
  },
  center: {
    alignItems: 'center',
    justifyContent: 'center'
  },
  blackBg: {
    backgroundColor: '#0c0c0c'
  },
  headerText: {
    marginTop: 30,
    width: screenWidth,
    textAlign: 'center',
    color: 'white'
  },
  container: {
    // fontFamily: "Roboto",
    flex: 1,
    flexDirection: 'column',
    backgroundColor: '#f2f2f2'
  },
  cardStack: {
    flex: 6,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ffffff'
  },
  card: {
    width: cardWidth,
    height: cardHeight,
    backgroundColor: '#fff'
  },
  label: {
    lineHeight: 400,
    textAlign: 'center',
    fontSize: 55,
    fontFamily: 'System',
    color: '#ffffff',
    backgroundColor: 'transparent'
  },
  footer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ffffff'
  },
  buttonContainer: {
    width: 220,
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  button: {
    shadowColor: 'rgba(0,0,0,0.3)',
    shadowOffset: {
      width: 0,
      height: 1
    },
    shadowOpacity: 0.5,
    // backgroundColor:'#fff',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 0
  },
  overlay: {
    flex: 1,
    position: 'absolute',
    left: 0,
    top: 0,
    backgroundColor: '#000',
    width: screenWidth,
    height: screenHeight,
    justifyContent: 'center',
    alignItems: 'center'
  },
  foodDetail: {
    // paddingHorizontal: 0,
    paddingVertical: 10
  },
  foodDetailView: {
    flexDirection: 'row'
  },
  flex1: {
    // flex: 1
  },
  foodName: {
    fontSize: 16,
    textAlign: 'left'
  },
  foodCost: {
    fontSize: 16,
    color: 'green',
    textAlign: 'right'
  },
  starRateView: {
    flexDirection: 'row',
    paddingBottom: 2
  },
  starRate: {
    textAlign: 'left',
    width: 70,
    paddingLeft: 1,
    paddingRight: 5,
    marginTop: 1
  },
  starRateValue: {
    fontSize: 10,
    justifyContent: 'flex-end'
  }
});
