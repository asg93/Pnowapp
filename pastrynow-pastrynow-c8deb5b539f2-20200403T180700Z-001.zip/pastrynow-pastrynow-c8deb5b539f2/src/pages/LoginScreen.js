import React, { Component } from 'react';
import { KeyboardAvoidingView, StyleSheet } from 'react-native';
import { withNavigation } from 'react-navigation';
import Dimensions from 'Dimensions';
import UserInput from '../components/UserInput';
import Wallpaper from '../components/Wallpaper';
import Logo from '../components/Logo';
import ButtonSubmit from '../components/LoginSubmit';
import SignupSection from '../components/SignupSection';

import loginwallpaper from '../images/wallpaper.jpg';
import emailImg from '../images/email.png';
import passwordImg from '../images/password.png';

class LoginScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showPass: true,
      press: false,
      isValidName: false,
      isValidEmail: false,
      isValidPass: false,
      isFieldEmpty: true,
      email: '',
      pass: ''
    };
    this.showPass = this.showPass.bind(this);
  }

  showPass() {
    this.state.press === false
      ? this.setState({ showPass: false, press: true })
      : this.setState({ showPass: true, press: false });
  }

  validateEmail = text => {
    console.log(text);
    if (text !== '' && text !== ' ' && text !== null) {
      this.setState({ isValidEmail: true });
      this.setState({ email: text });
      if (this.state.isValidPass) {
        this.setState({ isFieldEmpty: false });
      }
    } else {
      this.setState({ isValidEmail: false });
      this.setState({ isFieldEmpty: true });
    }
    console.log(this.state.isFieldEmpty);
  };

  validatePass = text => {
    console.log(text);
    if (text !== '' && text !== ' ' && text !== null) {
      this.setState({ isValidPass: true });
      this.setState({ pass: text });
      if (this.state.isValidEmail) {
        this.setState({ isFieldEmpty: false });
      }
    } else {
      this.setState({ isValidPass: false });
      this.setState({ isFieldEmpty: true });
    }
    console.log(this.state.isFieldEmpty);
  };

  render() {
    const { name, email, pass } = this.state;
    return (
      <Wallpaper source={loginwallpaper}>
        <Logo />
        <KeyboardAvoidingView style={styles.container}>
          <UserInput
            keyboardType="email-address"
            ref="Email"
            source={emailImg}
            placeholder="Email"
            autoCapitalize={'none'}
            returnKeyType={'next'}
            autoFocus={true}
            autoCorrect={false}
            onSubmitEditing={event => {
              this.refs.Password.focus();
            }}
            onChange={email => this.validateEmail(email)}
            value={email}
          />
          <UserInput
            ref="Password"
            source={passwordImg}
            secureTextEntry={this.state.showPass}
            placeholder="Password"
            returnKeyType={'done'}
            autoCapitalize={'none'}
            autoCorrect={false}
            onChange={pass => this.validatePass(pass)}
            value={pass}
          />
        </KeyboardAvoidingView>
        <ButtonSubmit
          text="Login"
          isFieldEmpty={this.state.isFieldEmpty}
          email={this.state.email}
          pass={this.state.pass}
        />
        <SignupSection />
      </Wallpaper>
    );
  }
}

export default withNavigation(LoginScreen);

const DEVICE_WIDTH = Dimensions.get('window').width;
const DEVICE_HEIGHT = Dimensions.get('window').height;

const styles = StyleSheet.create({
  container: {},
  btnEye: {
    position: 'absolute',
    top: 60,
    right: 28
  },
  iconEye: {
    width: 25,
    height: 25,
    tintColor: 'rgba(0,0,0,0.2)'
  }
});
