import React, { Component } from 'react';
import {
  ActivityIndicator,
  Alert,
  AsyncStorage,
  Image,
  Picker,
  RefreshControl,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  View
} from 'react-native';
import {
  Body,
  Button,
  Card,
  CardItem,
  Content,
  List,
  ListItem,
  Text
} from 'native-base';
import image from '../images/2.jpg';
import Ionicons from 'react-native-vector-icons/Ionicons';
import * as Api from '../api/pastrynow';

import { connect } from 'react-redux';
import {
  removeFromCart,
  quantityUp,
  quantityDown,
  emptyCart
} from '../redux/actions';

class CartScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      cartItems: null,
      isLoading: true,
      deliveryLocation: null
    };
  }

  static navigationOptions = ({ navigation }) => {
    return {
      title: 'Cart',
      tabBarVisible: 'false'
    };
  };

  componentDidMount() {
    this.loadCart();
    this.loadAddress();
  }

  _onRefresh = () => {
    this.componentDidMount();
  };

  onAddress() {
    this.props.navigation.navigate('Address');
  }

  onSubmitOrder = () => {
    this.setState({
      isLoading: true
    });
    if (this.props.deliveryLocation === null) {
      this.setState({
        isLoading: false
      });
      Alert.alert('Oops!', 'Please select/add an address');
      return 0;
    }
    Api.submitOrder(
      this.props.cartItems[0].chef.id,
      this.props.deliveryLocation.id,
      this.props.cartItems
    ).then(responseJson => {
      if (responseJson.success === true) {
        this.props.emptyCart();
        this.setState(
          {
            isLoading: false,
            cartItems: null
          },
          () =>
            this.props.navigation.navigate('Orders', {
              onGoBack: () => this._onRefresh()
            })
        );
      } else {
        Alert.alert('Error', responseJson.message);
      }
    });
  };

  loadCart = () => {
    this.setState({ isLoading: true });
    try {
      AsyncStorage.getItem('cartItems', (err, result) => {
        var jsonResult = JSON.parse(result);
        if (jsonResult !== null) {
          jsonResult.forEach(function(element, index) {
            element.quantity = 1;
          });
        }

        this.setState({
          isLoading: false,
          cartItems: jsonResult
        });
        console.log('result: ', JSON.parse(result));
      });
    } catch (e) {
      this.setState({ isLoading: false });
    }
  };

  loadAddress = () => {
    this.state.isLoading = true;
    AsyncStorage.getItem('deliveryLocation', (err, result) => {
      this.setState({
        isLoading: false,
        deliveryLocation: JSON.parse(result)
      });
      console.log('deliveryLocation: ', JSON.parse(result));
    });
  };

  _removeItem = (item, key) => {
    this.state.isLoading = true;
    // AsyncStorage.getItem('cartItems', (err, result) => {
    //   var oldCartItems = JSON.parse(result);
    //   var newCartItems = oldCartItems.filter(function(oldCartItem) {
    //     return oldCartItem.id !== item.id;
    //   });
    //   this.setState({
    //     isLoading: false,
    //     cartItems: newCartItems
    //   });
    //   AsyncStorage.setItem('cartItems', JSON.stringify(newCartItems));
    // });
    this.props.removeFromCart();
    this.setState({
      isLoading: false
    });
  };

  _quantityUp = (item, key) => {
    console.log(
      'id, quantity',
      item.id,
      typeof item.quantity === 'undefined' ? 1 : item.quantity
    );
    this.props.quantityUp(
      item.id,
      typeof item.quantity === 'undefined' ? 1 : item.quantity
    );
  };
  _quantityDown = (item, key) => {
    console.log(
      'id, quantity',
      item.id,
      typeof item.quantity === 'undefined' ? 1 : item.quantity
    );
    this.props.quantityDown(
      item.id,
      typeof item.quantity === 'undefined' ? 1 : item.quantity
    );
  };

  renderAddress() {
    console.log(this.props.deliveryLocation);
    if (this.props.deliveryLocation !== null) {
      return (
        <CardItem style={{ flexDirection: 'column', alignItems: 'flex-start' }}>
          <Text style={{ color: '#a2a2a2' }}>
            {this.props.deliveryLocation.street_address}
          </Text>
          <Text style={{ color: '#a2a2a2' }}>
            {this.props.deliveryLocation.address_line_2}
          </Text>
          <Text style={{ color: '#a2a2a2' }}>
            {this.props.deliveryLocation.city}
          </Text>
          <Text style={{ color: '#a2a2a2' }}>
            {this.props.deliveryLocation.state}
          </Text>
          <Text style={{ color: '#a2a2a2' }}>
            {this.props.deliveryLocation.zip}
          </Text>
        </CardItem>
      );
    } else {
      return (
        <CardItem style={{ flexDirection: 'column', alignItems: 'flex-start' }}>
          <Text style={{ color: '#a2a2a2' }}>Select Address</Text>
        </CardItem>
      );
    }
  }

  setPickerValue(itemValue, key) {
    console.log('crtt: ', this.state.cartItems[key].quantity);
    this.state.cartItems[key].quantity = itemValue;
  }

  render() {
    if (this.state.isLoading) {
      return (
        <SafeAreaView style={{ flex: 1 }}>
          <View style={styles.emptyContainer}>
            <ActivityIndicator />
          </View>
        </SafeAreaView>
      );
    } else if (
      this.props.cartItems === null ||
      this.props.cartItems.length === 0
    ) {
      return (
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={this.state.refreshing}
              onRefresh={this._onRefresh}
            />
          }
          scrollEventThrottle={200}
          directionalLockEnabled={true}
        >
          <View style={styles.container}>
            <Text style={styles.welcome}>Cart is empty!</Text>
          </View>
        </ScrollView>
      );
    } else {
      console.log(this.props.cartItems);
      return (
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={this.state.isLoading}
              onRefresh={this._onRefresh}
            />
          }
          scrollEventThrottle={200}
          directionalLockEnabled={true}
        >
          <Content>
            <Card>
              <CardItem>
                <View style={styles.hcontainer}>
                  <Image
                    source={{ uri: this.props.cartItems[0].chef.image }}
                    style={styles.image}
                  />
                  <View style={styles.tcontainer}>
                    <Text style={styles.bheader}>
                      {this.props.cartItems[0].chef.name}
                    </Text>
                    <Text style={styles.baddress}>
                      {this.props.cartItems[0].chef.phone}
                    </Text>
                    <Text style={styles.baddress}>Ohio, USA</Text>
                  </View>
                </View>
              </CardItem>
              <CardItem>
                <Body>
                  <Text>Payment Mode:</Text>
                  <Text style={styles.mode}>Cash on delivery</Text>
                </Body>
              </CardItem>
              <CardItem>
                <Body>
                  <Text>In Cart</Text>
                  <List style={{ width: '100%' }}>
                    {this.props.cartItems.map((item, key) => (
                      <ListItem key={key}>
                        <View
                          style={{
                            flex: 1,
                            flexDirection: 'row',
                            alignItems: 'center'
                          }}
                        >
                          <View
                            style={{
                              flex: 5,
                              flexDirection: 'row'
                            }}
                          >
                            <Text style={{ fontSize: 14 }}>{item.name}</Text>

                            <View
                              style={{
                                flex: 1,
                                flexDirection: 'row',
                                justifyContent: 'flex-end'
                              }}
                            >
                              <View
                                style={{
                                  flexDirection: 'row',
                                  borderColor: '#dddddd',
                                  borderWidth: 1
                                }}
                              >
                                <TouchableOpacity
                                  style={{ padding: 10 }}
                                  onPress={() => this._quantityDown(item, key)}
                                >
                                  <Text
                                    style={{ fontWeight: 'bold', fontSize: 15 }}
                                  >
                                    -
                                  </Text>
                                </TouchableOpacity>
                                <Text style={{ color: 'green', fontSize: 14 }}>
                                  {typeof item.quantity !== 'undefined'
                                    ? item.quantity
                                    : 1}
                                </Text>
                                <TouchableOpacity
                                  style={{ padding: 10 }}
                                  onPress={() => this._quantityUp(item, key)}
                                >
                                  <Text
                                    style={{
                                      fontWeight: 'bold',
                                      fontSize: 15,
                                      color: 'green'
                                    }}
                                  >
                                    +
                                  </Text>
                                </TouchableOpacity>
                              </View>
                            </View>
                          </View>

                          <View
                            style={{
                              flex: 1,
                              flexDirection: 'row',
                              justifyContent: 'flex-end',
                              marginRight: 10
                            }}
                          >
                            <Text style={{ fontSize: 14 }}>${item.amount}</Text>
                          </View>

                          {/*<TouchableOpacity*/}
                          {/*  onPress={() => this._removeItem(item, key)}*/}
                          {/*  style={{*/}
                          {/*    flexDirection: 'row',*/}
                          {/*    marginLeft: 'auto'*/}
                          {/*  }}*/}
                          {/*>*/}
                          {/*  <Ionicons*/}
                          {/*    name={'md-trash'}*/}
                          {/*    color={'#000'}*/}
                          {/*    size={20}*/}
                          {/*  />*/}
                          {/*</TouchableOpacity>*/}
                        </View>
                      </ListItem>
                    ))}
                  </List>
                </Body>
              </CardItem>
              <CardItem>
                <Button
                  bordered
                  style={{ borderColor: 'green' }}
                  onPress={() => this.onAddress()}
                >
                  <Text style={{ color: 'green' }}>Select Address</Text>
                </Button>
              </CardItem>

              {this.renderAddress()}

              <CardItem>
                <Button
                  bordered
                  onPress={() => this.onSubmitOrder()}
                  style={{
                    width: '100%',
                    borderColor: 'tomato',
                    justifyContent: 'center'
                  }}
                >
                  <Text style={{ color: 'tomato' }}>Order</Text>
                </Button>
              </CardItem>
            </Card>
          </Content>
        </ScrollView>
      );
    }
  }
}

function mapStateToProps(state) {
  return {
    deliveryLocation: state.deliveryLocation,
    cartItems: state.cartItems
  };
}

function mapDispatchToProps(dispatch) {
  return {
    removeFromCart: id => dispatch(removeFromCart(id)),
    emptyCart: () => dispatch(emptyCart()),
    quantityUp: (id, value) => dispatch(quantityUp(id, value)),
    quantityDown: (id, value) => dispatch(quantityDown(id, value))
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(CartScreen);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF'
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5
  },
  hcontainer: {
    flexDirection: 'row',
    justifyContent: 'flex-start'
  },
  tcontainer: {
    flexDirection: 'column',
    justifyContent: 'flex-start'
  },
  bheader: {
    marginLeft: 10,
    fontWeight: 'bold',
    color: '#424242'
  },
  baddress: {
    marginLeft: 10,
    color: 'grey'
  },
  image: {
    width: 80,
    height: 80
  },
  mode: {
    color: 'tomato'
  }
});
