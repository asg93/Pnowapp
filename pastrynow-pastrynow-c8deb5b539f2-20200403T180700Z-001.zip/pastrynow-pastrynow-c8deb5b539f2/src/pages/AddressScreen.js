import React, { Component } from 'react';
import {
  ActivityIndicator,
  Alert,
  AsyncStorage,
  RefreshControl,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  View
} from 'react-native';
import { Button, Form, Input, Item, List, ListItem, Text } from 'native-base';

import * as Api from '../api/pastrynow';

import { connect } from 'react-redux';
import { selectDeliveryLocation } from '../redux/actions';

class AddressScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: true,
      address: [],
      defaultAddress: null,
      street_address: '',
      address_line_2: '',
      city: '',
      state: '',
      zip: ''
    };
  }

  static navigationOptions = ({ navigation }) => {
    return {
      title: 'Address',
      tabBarVisible: 'false'
    };
  };

  componentDidMount() {
    this.loadAddress();
    this.loadDefaultAddress();
  }

  loadAddress() {
    this.state.isLoading = true;
    Api.addresses().then(responseJson => {
      if (responseJson.success === true) {
        this.setState({
          isLoading: false,
          address: responseJson.data
        });
        AsyncStorage.setItem('address', JSON.stringify(responseJson.data));
      }
    });
  }

  loadDefaultAddress() {
    this.state.isLoading = true;
    AsyncStorage.getItem('deliveryLocation', (err, result) => {
      this.setState({
        isLoading: false,
        defaultAddress: JSON.parse(result)
      });
      console.log('deliveryLocation: ', JSON.parse(result));
    });
  }

  addAddress() {
    console.log('enter');
    Api.addAddress(
      this.state.street_address,
      this.state.address_line_2,
      this.state.city,
      this.state.state,
      this.state.zip
    ).then(responsJson => {
      if (responsJson.success === true) {
        AsyncStorage.getItem('address', (err, result) => {
          var address = JSON.parse(result);
          var newAddress = {
            street_address: this.state.street_address,
            address_line_2: this.state.address_line_2,
            city: this.state.city,
            state: this.state.state,
            zip: this.state.zip
          };
          if (address === null) {
            address = [newAddress];
          } else {
            address.push(newAddress);
          }
          AsyncStorage.setItem('address', JSON.stringify(address));
          this.componentDidMount();
          console.log('enter2');
        });
      } else {
        Alert.alert('Error', responsJson.message);
      }
    });
  }

  onAddress(item, key) {
    this.props.selectDeliveryLocation(item);
    this.props.navigation.goBack();
  }

  renderAddress() {
    console.log('address::', this.state.address);
    if (this.state.address !== null && this.state.address.length !== 0) {
      return this.state.address.map((item, key) => (
        <ListItem style={{ flexDirection: 'row' }} key={item.id}>
          <View style={{ flex: 1 }}>
            <Text style={{ color: '#707070' }}>{item.street_address}</Text>
            <Text style={{ color: '#707070' }}>{item.address_line_2}</Text>
            <Text style={{ color: '#707070' }}>{item.city}</Text>
            <Text style={{ color: '#707070' }}>{item.state}</Text>
            <Text style={{ color: '#707070' }}>{item.zip}</Text>
          </View>
          <View style={{ flex: 1, marginLeft: 10, alignItems: 'flex-end' }}>
            <Button
              bordered
              style={{ borderColor: 'green' }}
              onPress={() => this.onAddress(item, key)}
            >
              <Text style={{ color: 'green' }}>Select</Text>
            </Button>
          </View>
        </ListItem>
      ));
    } else {
      return (
        <ListItem style={{ alignItems: 'flex-start' }}>
          <Text style={{ color: '#a2a2a2' }}>Add Address</Text>
        </ListItem>
      );
    }
  }

  render() {
    if (this.state.isLoading) {
      return (
        <SafeAreaView style={[styles.safeArea, styles.alignJustifyCenter]}>
          <ActivityIndicator />
        </SafeAreaView>
      );
    } else {
      return (
        <ScrollView
          style={styles.safeArea}
          refreshControl={
            <RefreshControl
              refreshing={this.state.isLoading}
              onRefresh={this._onRefresh}
            />
          }
          scrollEventThrottle={200}
          directionalLockEnabled={true}
        >
          <Text style={{ color: '#000', fontSize: 20, margin: 10 }}>
            Manage Address
          </Text>
          <List style={{ width: '100%' }}>{this.renderAddress()}</List>
          <Text style={{ color: '#000', fontSize: 20, margin: 10 }}>
            New Address
          </Text>
          <Form>
            <Item>
              <Input
                placeholder="Street Address"
                onChangeText={street_address => {
                  this.setState({ street_address: street_address });
                }}
              />
            </Item>
            <Item>
              <Input
                placeholder="Address Line 2 "
                onChangeText={address_line_2 => {
                  this.setState({ address_line_2: address_line_2 });
                }}
              />
            </Item>
            <Item>
              <Input
                placeholder="City "
                onChangeText={city => {
                  this.setState({ city: city });
                }}
              />
            </Item>
            <Item>
              <Input
                placeholder="State / Province / Region "
                onChangeText={state => {
                  this.setState({ state: state });
                }}
              />
            </Item>
            <Item>
              <Input
                placeholder="Postal / Zip Code "
                onChangeText={zip => {
                  this.setState({ zip: zip });
                }}
              />
            </Item>
            <Item>
              <Button
                bordered
                style={{
                  borderColor: 'green',
                  justifyContent: 'center',
                  marginTop: 10,
                  marginBottom: 10
                }}
                onPress={() => this.addAddress()}
              >
                <Text style={{ color: 'green' }}>Add</Text>
              </Button>
            </Item>
          </Form>
        </ScrollView>
      );
    }
  }
}

function mapStateToProps(state) {
  return {
    deliveryLocation: state.deliveryLocation
  };
}

function mapDispatchToProps(dispatch) {
  return {
    selectDeliveryLocation: address => dispatch(selectDeliveryLocation(address))
  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(AddressScreen);

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#ffffff'
  },
  alignJustifyCenter: {
    alignItems: 'center',
    justifyContent: 'center'
  }
});
