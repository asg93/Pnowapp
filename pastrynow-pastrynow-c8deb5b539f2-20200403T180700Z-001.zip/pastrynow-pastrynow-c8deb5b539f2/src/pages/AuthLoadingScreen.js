import React, { Component } from 'react';
import { AsyncStorage, StyleSheet } from 'react-native';
import { withNavigation } from 'react-navigation';
import Dimensions from 'Dimensions';
import Wallpaper from '../components/Wallpaper';
import Logo from '../components/Logo';

import loginwallpaper from '../images/wallpaper.jpg';

class AuthLoadingScreen extends Component {
  constructor(props) {
    super(props);
    this._bootstrapAsync();
    this.state = {};
  }

  // Fetch the token from storage then navigate to our appropriate place
  _bootstrapAsync = async () => {
    const userToken = await AsyncStorage.getItem('accessToken');
    console.log('token: ' + userToken);

    // This will switch to the App screen or Auth screen and this loading
    // screen will be unmounted and thrown away.
    this.props.navigation.navigate(userToken ? 'Main' : 'Auth');
  };

  render() {
    const { name, email, pass } = this.state;
    return (
      <Wallpaper source={loginwallpaper}>
        <Logo />
      </Wallpaper>
    );
  }
}

export default withNavigation(AuthLoadingScreen);

const DEVICE_WIDTH = Dimensions.get('window').width;
const DEVICE_HEIGHT = Dimensions.get('window').height;

const styles = StyleSheet.create({
  container: {},
  btnEye: {
    position: 'absolute',
    top: 60,
    right: 28
  },
  iconEye: {
    width: 25,
    height: 25,
    tintColor: 'rgba(0,0,0,0.2)'
  }
});
