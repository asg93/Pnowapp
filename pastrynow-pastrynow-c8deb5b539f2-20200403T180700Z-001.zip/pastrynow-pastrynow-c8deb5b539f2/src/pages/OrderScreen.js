import React, { Component } from 'react';
import {
  ActivityIndicator,
  RefreshControl,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  View
} from 'react-native';
import {
  Body,
  Button,
  Container,
  Content,
  Left,
  List,
  ListItem,
  Right,
  Text,
  Thumbnail
} from 'native-base';
import * as Api from '../api/pastrynow';

import image from '../images/2.jpg';

export default class OrderScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      upcoming: null,
      past: null,
      isLoading: true
    };
  }

  componentDidMount() {
    this._loadOrders();
  }

  _loadOrders = () => {
    this.setState({
      isLoading: true
    });
    Api.getOrders().then(responseJson => {
      if (responseJson.success === true) {
        this.setState({
          isLoading: false,
          upcoming: responseJson.data.upcoming,
          past: responseJson.data.past
        });
      }
    });
  };

  static navigationOptions = ({ navigation }) => {
    return {
      title: 'Orders'
    };
  };

  onPress(item, key) {
    console.log('status click');
    this.props.navigation.navigate('OrderDetails', {
      item: item,
      key: key
    });
  }
  _onRefresh = () => {
    this.componentDidMount();
  };

  renderOrders = (item, key) => {
    console.log('chef: ', item.chef);

    return (
      <List key={key}>
        <ListItem thumbnail onPress={() => this.onPress(item, key)}>
          <Left>
            <Thumbnail square source={{ uri: item.chef.image }} />
          </Left>
          <Body>
            <Text>{item.chef.name}</Text>
            <Text note numberOfLines={1}>
              {item.brief}{' '}
            </Text>
          </Body>
          <Right>
            <Button transparent>
              <Text>{item.status}</Text>
            </Button>
          </Right>
        </ListItem>
      </List>
    );
  };

  render() {
    if (this.state.isLoading) {
      return (
        <SafeAreaView style={{ flex: 1 }}>
          <View style={styles.emptyContainer}>
            <ActivityIndicator />
          </View>
        </SafeAreaView>
      );
    } else if (
      (this.state.upcoming === null && this.state.past === null) ||
      (this.state.upcoming.length === 0 && this.state.past.length === 0)
    ) {
      return (
        <View style={styles.emptyContainer}>
          <Text style={styles.welcome}>No orders</Text>
        </View>
      );
    } else {
      return (
        <SafeAreaView>
          <ScrollView
            refreshControl={
              <RefreshControl
                refreshing={this.state.isLoading}
                onRefresh={this._onRefresh}
              />
            }
            scrollEventThrottle={200}
            directionalLockEnabled={true}
          >
            <Container>
              <Content>
                <ListItem itemDivider>
                  <Text>Upcoming</Text>
                </ListItem>
                {this.state.upcoming.map(
                  (item, key) => this.renderOrders(item, key),
                  this
                )}
                <ListItem itemDivider>
                  <Text>Past</Text>
                </ListItem>
                {this.state.past.map(
                  (item, key) => this.renderOrders(item, key),
                  this
                )}
              </Content>
            </Container>
          </ScrollView>
        </SafeAreaView>
      );
    }
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#EEEEEE'
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF'
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10
  },
  header: {
    backgroundColor: '#FAFAFA'
  },
  headerTitle: {
    color: '#424242'
  }
});
