import React, { Component } from 'react';
import { Image, Linking, StyleSheet, View } from 'react-native';
import {
  Body,
  Button,
  Card,
  CardItem,
  Container,
  Content,
  List,
  ListItem,
  Text
} from 'native-base';
import image from '../images/2.jpg';

export default class OrderScreen extends Component {
  static navigationOptions = ({ navigation }) => {
    return {
      title: 'Order Details',
      tabBarVisible: 'false'
    };
  };

  onPress = (item, key) => {
    Linking.openURL(`tel:${item.phone}`);
  };

  render() {
    let item = this.props.navigation.getParam('item', null);
    let key = this.props.navigation.getParam('key', null);
    console.log('ittttem: ', item);
    return (
      <Container>
        <Content>
          <Card>
            <CardItem>
              <View style={styles.hcontainer}>
                <Image source={{ uri: item.chef.image }} style={styles.image} />
                <View style={styles.tcontainer}>
                  <Text style={styles.bheader}>{item.chef.name}</Text>
                  <Text style={styles.baddress}>{item.chef.phone}</Text>
                  <Text style={styles.baddress}>Ohio, USA</Text>
                </View>
              </View>
            </CardItem>
            <CardItem>
              <Body>
                <Text>Status</Text>
                <Text style={styles.status}>{item.status}</Text>
              </Body>
            </CardItem>
            <CardItem>
              <Body>
                <Text>Bill Details</Text>
                <List style={{ width: '100%' }}>
                  {item.ordered_items.map((item, key) => (
                    <ListItem key={key}>
                      <View style={{ flex: 1, flexDirection: 'row' }}>
                        <View style={{ flex: 1 }}>
                          <Text>
                            {item.details.name} x {item.quantity}
                          </Text>
                        </View>
                        <View style={{ flex: 1 }}>
                          <Text style={{ textAlign: 'right' }}>
                            ${item.total_amount}
                          </Text>
                        </View>
                      </View>
                    </ListItem>
                  ))}
                  <ListItem>
                    <View
                      style={{
                        flex: 1,
                        flexDirection: 'row',
                        justifyContent: 'flex-start'
                      }}
                    >
                      <View style={{ flex: 1 }}>
                        <Text style={{ fontWeight: 'bold' }}>Total</Text>
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={{ textAlign: 'right' }}>
                          ${item.total_amount}
                        </Text>
                      </View>
                    </View>
                  </ListItem>
                </List>
              </Body>
            </CardItem>
            <CardItem>
              <Button
                bordered
                style={{ borderColor: 'tomato' }}
                onPress={() => this.onPress(item, key)}
              >
                <Text style={{ color: 'tomato' }}>Contact</Text>
              </Button>
            </CardItem>
          </Card>
        </Content>
      </Container>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#EEEEEE'
  },
  hcontainer: {
    flexDirection: 'row',
    justifyContent: 'flex-start'
  },
  tcontainer: {
    flexDirection: 'column',
    justifyContent: 'flex-start'
  },
  bheader: {
    marginLeft: 10,
    fontWeight: 'bold',
    color: '#424242'
  },
  baddress: {
    marginLeft: 10,
    color: 'grey'
  },
  image: {
    width: 80,
    height: 80
  },
  status: {
    color: 'tomato'
  }
});
