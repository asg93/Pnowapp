import React, { Component } from 'react';
import { KeyboardAvoidingView, StyleSheet } from 'react-native';
import { withNavigation } from 'react-navigation';
import Dimensions from 'Dimensions';
import Wallpaper from '../components/Wallpaper';
import Logo from '../components/Logo';
import ButtonSubmit from '../components/RegisterSubmit';
import UserInput from '../components/UserInput';

import registerwallpaper from '../images/wallpaper2.jpg';
import usernameImg from '../images/username.png';
import emailImg from '../images/email.png';
import passwordImg from '../images/password.png';

class RegisterScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showPass: true,
      press: false,
      isValidName: false,
      isValidEmail: false,
      isValidPass: false,
      isFieldEmpty: true,
      pass: '',
      email: '',
      name: ''
    };
    this.showPass = this.showPass.bind(this);
  }

  showPass() {
    this.state.press === false
      ? this.setState({ showPass: false, press: true })
      : this.setState({ showPass: true, press: false });
  }

  validateName = text => {
    console.log(text);
    if (text !== '' && text !== ' ' && text !== null) {
      this.setState({ isValidName: true });
      this.setState({ name: text });
      if (this.state.isValidEmail && this.state.isValidPass) {
        this.setState({ isFieldEmpty: false });
      }
    } else {
      this.setState({ isValidName: false });
      this.setState({ isFieldEmpty: true });
    }
    console.log(this.state.isFieldEmpty);
  };

  validateEmail = text => {
    console.log(text);
    if (text !== '' && text !== ' ' && text !== null) {
      this.setState({ isValidEmail: true });
      this.setState({ email: text });
      if (this.state.isValidName && this.state.isValidPass) {
        this.setState({ isFieldEmpty: false });
      }
    } else {
      this.setState({ isValidEmail: false });
      this.setState({ isFieldEmpty: true });
    }
    console.log(this.state.isFieldEmpty);
  };

  validatePass = text => {
    console.log(text);
    if (text !== '' && text !== ' ' && text !== null) {
      this.setState({ isValidPass: true });
      if (this.state.isValidEmail && this.state.isValidName) {
        this.setState({ isFieldEmpty: false });
        this.setState({ pass: text });
      }
    } else {
      this.setState({ isValidPass: false });
      this.setState({ isFieldEmpty: true });
    }
    console.log(this.state.isFieldEmpty);
  };

  render() {
    const { name, email, pass } = this.state;
    return (
      <Wallpaper source={registerwallpaper}>
        <Logo />
        <KeyboardAvoidingView style={styles.container}>
          <UserInput
            ref="Name"
            source={usernameImg}
            placeholder="Name"
            autoCapitalize={'none'}
            returnKeyType={'next'}
            autoFocus={true}
            autoCorrect={false}
            onSubmitEditing={event => {
              this.refs.Password.focus();
            }}
            onChange={name => this.validateName(name)}
            value={name}
          />
          <UserInput
            keyboardType="email-address"
            ref="Email"
            source={emailImg}
            placeholder="Email"
            autoCapitalize={'none'}
            returnKeyType={'next'}
            autoFocus={true}
            autoCorrect={false}
            onSubmitEditing={event => {
              this.refs.Password.focus();
            }}
            onChange={email => this.validateEmail(email)}
            value={email}
          />
          <UserInput
            ref="Password"
            source={passwordImg}
            secureTextEntry={this.state.showPass}
            placeholder="Password"
            returnKeyType={'done'}
            autoCapitalize={'none'}
            autoCorrect={false}
            onChange={pass => this.validatePass(pass)}
            value={pass}
          />
        </KeyboardAvoidingView>
        <ButtonSubmit
          text="Register"
          isFieldEmpty={this.state.isFieldEmpty}
          name={this.state.name}
          email={this.state.email}
          pass={this.state.pass}
        />
      </Wallpaper>
    );
  }
}

const DEVICE_WIDTH = Dimensions.get('window').width;
const DEVICE_HEIGHT = Dimensions.get('window').height;

const styles = StyleSheet.create({
  container: {},
  btnEye: {
    position: 'absolute',
    top: 60,
    right: 28
  },
  iconEye: {
    width: 25,
    height: 25,
    tintColor: 'rgba(0,0,0,0.2)'
  }
});

export default withNavigation(RegisterScreen);
